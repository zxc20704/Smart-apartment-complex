# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import tkinter as tk
import os

window=tk.Tk()
window.title('住戶辨識系統')
window.geometry('480x360')


def shoot():
    os.system("python get_my_faces.py")
b=tk.Button(window,text='住戶拍攝',width=15,
            height=2,command=shoot)
b.pack()

def intercept():
    os.system("python set_other_people.py")
c=tk.Button(window,text='照片截圖',width=15,
            height=2,command=intercept)
c.pack()

def train():
    os.system("python train_faces.py")
d=tk.Button(window,text='照片訓練',width=15,
            height=2,command=train)
d.pack()

def identification():
    os.system("python is_my_face_v2.py")
e=tk.Button(window,text='住戶辨識',width=15,
            height=2,command=identification)
e.pack()



   
window.mainloop()