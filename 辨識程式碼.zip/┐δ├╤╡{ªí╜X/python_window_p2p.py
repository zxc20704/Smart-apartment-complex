# -*- coding: utf-8 -*-
"""
Created on Fri Oct 26 21:06:46 2018

@author: ERTA
"""

import tkinter as tk
import subprocess

window = tk.Tk()
window.title('my window')
window.geometry('480x360')

# 這裏是窗口的內容

l = tk.Label(window, 
    text='住戶辨識系統',    # 標籤的文本
    bg='white',     # 背景顏色
    width=15, height=2)  # 標籤長寬
l.pack()    # 固定窗口位置

def hit_me1():
    subprocess.call("python get_my_faces.py", shell=True)

b1 = tk.Button(window, 
    text='住戶拍攝',      # 顯示在按鈕上的文本
    width=15, height=2, 
    command=hit_me1)     # 點擊按鈕式執行的命令
b1.pack()    # 按鈕位置

def hit_me2():
    subprocess.call("python set_other_people.py", shell=True)

b2 = tk.Button(window, 
    text='照片截圖',      # 顯示在按鈕上的文本
    width=15, height=2, 
    command=hit_me2)     # 點擊按鈕式執行的命令
b2.pack()    # 按鈕位置

def hit_me3():
    subprocess.call("python train_faces.py", shell=True)

b2 = tk.Button(window,
    text='照片訓練',      # 顯示在按鈕上的文本
    width=15, height=2,
    command=hit_me3)     # 點擊按鈕式執行的命令
b2.pack()    # 按鈕位置

def hit_me4():
    subprocess.call("python is_my_face_v2.py", shell=True)

b2 = tk.Button(window,
    text='住戶辨識',      # 顯示在按鈕上的文本
    width=15, height=2,
    command=hit_me4)     # 點擊按鈕式執行的命令
b2.pack()    # 按鈕位置

window.mainloop()