# -*- coding: utf-8 -*-
"""
Created on Thu Jul 19 16:19:09 2018

@author: ERTA
"""

# -*- codeing: utf-8 -*-
import sys
import os
import cv2
import dlib


input_dir = './my_faces_timmy2000'
output_dir = './my_faces'
size = 64

if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# 使用dlib自带的frontal_face_detector作為我們的特徵提取器
detector = dlib.get_frontal_face_detector()

index = 1
for (path, dirnames, filenames) in os.walk(input_dir):
    for filename in filenames:
        if filename.endswith('.jpg'):
            print('Being processed picture %s' % index)
            img_path = path + '/' + filename
            # 從文件讀取圖片
            img = cv2.imread(img_path)
            # 轉為灰階圖片
            gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            # 使用detector進行人臉檢測 dets為返回的結果
            dets = detector(gray_img, 1)

            # 使用enumerate函數遍歷序列中的元素以及它們的下標
            # 下標i即為人臉序號
            # left：人臉左邊距離圖片左邊界的距離 ；right：人臉右邊距離圖片右邊界的距離
            # top：人臉上邊距離圖片上邊界的距離 ；bottom：人臉下邊距離圖片上邊界的距離
            for i, d in enumerate(dets):
                x1 = d.top() if d.top() > 0 else 0
                y1 = d.bottom() if d.bottom() > 0 else 0
                x2 = d.left() if d.left() > 0 else 0
                y2 = d.right() if d.right() > 0 else 0
                # img[y:y+h, x:x+w]
                face = img[x1:y1, x2:y2]
                # 調整圖片的尺寸
                face = cv2.resize(face, (size, size))
                cv2.imshow('image', face)
                # 保存圖片
                cv2.imwrite(output_dir + '/' + str(index) + '.jpg', face)
                index += 1

            key = cv2.waitKey(30) & 0xff
            if key == 27:
                sys.exit(0)